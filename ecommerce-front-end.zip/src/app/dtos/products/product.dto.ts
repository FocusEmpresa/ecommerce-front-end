export interface ProductDTO {
    _id?: string;
    product?: string;
    price?: number;
    max_parcelas?: number;
    description?: string;
    link?: string;
}